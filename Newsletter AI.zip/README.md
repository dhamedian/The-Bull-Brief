# The Bull Brief 📈

**AI-powered daily finance newsletter for high schoolers.**

## What This Is
A free website + email newsletter that publishes AI-generated financial news every weekday morning, written specifically for teenagers. No jargon, no fluff.

## Tech Stack (100% Free)
| Tool | Purpose | Cost |
|------|---------|------|
| GitHub Pages | Hosts the website | Free |
| GitHub Actions | Runs the daily automation | Free |
| Google Gemini 1.5 Flash | Generates all content | Free |
| Beehiiv | Email newsletter delivery | Free |

## File Structure
```
bullbrief/
├── index.html          ← The website (reads content.json)
├── content.json        ← Updated daily by AI (auto-generated)
├── update_content.py   ← The AI content generation script
├── .github/
│   └── workflows/
│       └── daily-update.yml  ← GitHub Actions automation
└── README.md
```

## Setup Steps (See full guide in the project)
1. Fork/upload this repo to GitHub
2. Get free Gemini API key at aistudio.google.com
3. Add key as GitHub Secret named GEMINI_API_KEY
4. Enable GitHub Pages (Settings → Pages → main branch)
5. Done — updates automatically every weekday morning

## For Developers
Run locally: open index.html in your browser.
Test the AI script: `GEMINI_API_KEY=your_key python update_content.py`
